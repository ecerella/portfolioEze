package com.portfolio.eze;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EzeApplication {

	public static void main(String[] args) {
		SpringApplication.run(EzeApplication.class, args);
	}

}
